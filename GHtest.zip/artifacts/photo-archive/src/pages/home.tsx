import { Link } from "wouter";
import { useGetStats, getGetStatsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ImageIcon, Users, BookOpen, Clock, AlertCircle } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function Home() {
  const { data: stats, isLoading } = useGetStats({
    query: { queryKey: getGetStatsQueryKey() }
  });

  return (
    <div className="space-y-12 animate-in fade-in duration-500">
      <section className="space-y-4">
        <h1 className="font-serif text-4xl md:text-5xl font-medium tracking-tight text-primary">
          Mabuhay. Welcome to Alaala.
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl leading-relaxed">
          Our family's digital heirloom. A place to preserve, remember, and discover the stories behind every photograph.
        </p>
      </section>

      {/* Stats Overview */}
      <section>
        <h2 className="font-serif text-2xl font-medium mb-6">Archive Overview</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {isLoading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <Card key={i} className="border-border/50 shadow-sm">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-8 w-8 rounded-full" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-16 mb-1" />
                </CardContent>
              </Card>
            ))
          ) : stats ? (
            <>
              <Card className="bg-card border-border/50 shadow-sm hover:border-primary/20 transition-colors">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Photographs</CardTitle>
                  <div className="p-2 bg-primary/10 rounded-full text-primary">
                    <ImageIcon className="h-4 w-4" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-serif font-semibold">{stats.totalPhotos}</div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border/50 shadow-sm hover:border-primary/20 transition-colors">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Identified Photos</CardTitle>
                  <div className="p-2 bg-primary/10 rounded-full text-primary">
                    <Clock className="h-4 w-4" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-serif font-semibold">{stats.identifiedPhotos}</div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border/50 shadow-sm hover:border-primary/20 transition-colors">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Albums</CardTitle>
                  <div className="p-2 bg-primary/10 rounded-full text-primary">
                    <BookOpen className="h-4 w-4" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-serif font-semibold">{stats.totalAlbums}</div>
                </CardContent>
              </Card>
              <Card className="bg-card border-border/50 shadow-sm hover:border-primary/20 transition-colors">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Family Members</CardTitle>
                  <div className="p-2 bg-primary/10 rounded-full text-primary">
                    <Users className="h-4 w-4" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-serif font-semibold">{stats.totalPeople}</div>
                </CardContent>
              </Card>
            </>
          ) : null}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Needs Identification Call to Action */}
        <section className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="font-serif text-2xl font-medium">Needs Your Help</h2>
            <Link href="/photos?needsIdentification=true">
              <Button variant="outline" size="sm">View All</Button>
            </Link>
          </div>
          
          <Card className="bg-[#fdf8f5] border-amber-200 shadow-sm overflow-hidden relative">
            <div className="absolute top-0 left-0 w-1 h-full bg-amber-500"></div>
            <CardContent className="p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center gap-6">
              <div className="p-4 bg-amber-100/50 rounded-full text-amber-700 shrink-0">
                <AlertCircle className="h-8 w-8" />
              </div>
              <div className="flex-1">
                <h3 className="font-serif text-xl font-medium text-amber-900 mb-2">
                  {stats?.unidentifiedPhotos || 0} Photographs Need Context
                </h3>
                <p className="text-amber-800/80 mb-4 text-sm leading-relaxed">
                  There are still many photos missing dates, locations, or names of the people in them. Your memories can help preserve these moments for the next generation.
                </p>
                <Link href="/photos?needsIdentification=true">
                  <Button className="bg-amber-700 hover:bg-amber-800 text-white shadow-sm">
                    Help Identify Photos
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Recent Activity */}
        <section className="space-y-6">
          <h2 className="font-serif text-2xl font-medium">Recent Memories</h2>
          <Card className="border-border/50 shadow-sm">
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-4 space-y-4">
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
                  <Skeleton className="h-16 w-full" />
                </div>
              ) : stats?.recentActivity && stats.recentActivity.length > 0 ? (
                <ul className="divide-y divide-border/50">
                  {stats.recentActivity.map((activity) => (
                    <li key={activity.id} className="p-4 hover:bg-muted/50 transition-colors">
                      <Link href={`/photos/${activity.photoId}`} className="flex items-start gap-3">
                        <div className="bg-primary/5 p-2 rounded-full mt-0.5">
                          <Clock className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm text-foreground">
                            <span className="font-medium">{activity.contributorName}</span> added a memory
                          </p>
                          <p className="text-xs text-muted-foreground line-clamp-1 mt-1">
                            "{activity.content}"
                          </p>
                          <p className="text-[10px] text-muted-foreground mt-2 uppercase tracking-wider">
                            {format(new Date(activity.createdAt), "MMM d, yyyy")}
                          </p>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              ) : (
                <div className="p-8 text-center text-muted-foreground text-sm">
                  No recent activity.
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </div>
    </div>
  );
}
