import { useParams, Link } from "wouter";
import { useGetAlbum, getGetAlbumQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { ImageIcon, Clock, MapPin, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function AlbumDetail() {
  const params = useParams();
  const id = Number(params.id);

  const { data: album, isLoading } = useGetAlbum(id, {
    query: { enabled: !!id, queryKey: getGetAlbumQueryKey(id) }
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center gap-4">
        <Link href="/albums">
          <Button variant="ghost" size="icon" className="rounded-full">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        {isLoading ? (
          <Skeleton className="h-10 w-64" />
        ) : (
          <div>
            <h1 className="font-serif text-3xl font-medium tracking-tight text-primary">
              {album?.name}
            </h1>
            <p className="text-muted-foreground mt-1">{album?.description}</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
        {isLoading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <Card key={i} className="overflow-hidden border-border/50">
              <Skeleton className="w-full aspect-square" />
            </Card>
          ))
        ) : album?.photos?.length === 0 ? (
          <div className="col-span-full py-16 text-center border-2 border-dashed border-border rounded-lg bg-card/50">
            <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="font-serif text-lg font-medium text-foreground mb-1">No Photos Yet</h3>
            <p className="text-muted-foreground text-sm">This album is waiting to be filled with memories.</p>
          </div>
        ) : (
          album?.photos?.map((photo, idx) => (
            <Link key={photo.id} href={`/photos/${photo.id}`}>
              <Card 
                className="overflow-hidden border-border/50 group cursor-pointer hover:shadow-md transition-all duration-300 bg-card rounded-md"
                style={{ animationDelay: `${idx * 50}ms` }}
              >
                <div className="aspect-square bg-muted relative overflow-hidden flex items-center justify-center p-2">
                  {/* Photo border effect for vintage feel */}
                  <div className="absolute inset-2 bg-white/10 z-10 border border-white/20 pointer-events-none" />
                  <img 
                    src={photo.imageUrl} 
                    alt={photo.title || "Untitled photograph"} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out sepia-[0.3]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {photo.needsIdentification && (
                    <div className="absolute top-3 right-3 bg-amber-500/90 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-0.5 rounded shadow-sm z-20">
                      Needs ID
                    </div>
                  )}
                  
                  <div className="absolute bottom-0 left-0 w-full p-4 transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 z-20 flex flex-col gap-1.5 text-white">
                    {photo.approximateYear && (
                      <div className="flex items-center gap-1.5 text-xs">
                        <Clock className="h-3.5 w-3.5" />
                        <span>{photo.approximateYear}</span>
                      </div>
                    )}
                    {photo.location && (
                      <div className="flex items-center gap-1.5 text-xs">
                        <MapPin className="h-3.5 w-3.5" />
                        <span className="truncate">{photo.location}</span>
                      </div>
                    )}
                  </div>
                </div>
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
