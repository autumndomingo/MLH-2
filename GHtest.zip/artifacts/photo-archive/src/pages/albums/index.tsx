import { useState } from "react";
import { useListAlbums, getListAlbumsQueryKey, useCreateAlbum } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, ImageIcon, Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
});

export default function Albums() {
  const { data: albums, isLoading } = useListAlbums({
    query: { queryKey: getListAlbumsQueryKey() }
  });

  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const createAlbum = useCreateAlbum();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      description: "",
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    createAlbum.mutate(
      { data: values },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListAlbumsQueryKey() });
          setOpen(false);
          form.reset();
          toast({ title: "Album created" });
        },
      }
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="font-serif text-3xl font-medium tracking-tight text-primary">Albums</h1>
          <p className="text-muted-foreground mt-2">Collections of our family's history.</p>
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" /> Create Album
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-serif text-xl">Create New Album</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Album Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Summer 1985" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (Optional)</FormLabel>
                      <FormControl>
                        <Textarea placeholder="A brief description of this collection..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={createAlbum.isPending} className="w-full">
                  Create Album
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => (
            <Card key={i} className="overflow-hidden border-border/50">
              <Skeleton className="w-full aspect-[4/3]" />
              <CardContent className="p-4 space-y-2">
                <Skeleton className="h-5 w-2/3" />
                <Skeleton className="h-4 w-1/3" />
              </CardContent>
            </Card>
          ))
        ) : albums?.length === 0 ? (
          <div className="col-span-full py-16 text-center border-2 border-dashed border-border rounded-lg bg-card/50">
            <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="font-serif text-lg font-medium text-foreground mb-1">No Albums Yet</h3>
            <p className="text-muted-foreground text-sm mb-4">Albums organize photos into collections.</p>
            <Button variant="outline" onClick={() => setOpen(true)}>Create the first album</Button>
          </div>
        ) : (
          albums?.map((album, idx) => {
            const progress = album.photoCount && album.photoCount > 0 
              ? Math.round(((album.identifiedCount || 0) / album.photoCount) * 100) 
              : 0;

            return (
              <Link key={album.id} href={`/albums/${album.id}`}>
                <Card className="overflow-hidden border-border/50 group cursor-pointer hover:shadow-md transition-all duration-300 bg-card">
                  <div className="aspect-[4/3] bg-muted relative overflow-hidden flex items-center justify-center p-2">
                    <div className="absolute inset-2 bg-white/10 z-10 border border-white/20 pointer-events-none" />
                    {album.coverPhotoUrl ? (
                      <img 
                        src={album.coverPhotoUrl} 
                        alt={album.name} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out sepia-[0.2]"
                      />
                    ) : (
                      <BookOpen className="h-12 w-12 text-muted-foreground opacity-20" />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-20" />
                  </div>
                  <CardContent className="p-5">
                    <h3 className="font-serif text-lg font-medium text-foreground group-hover:text-primary transition-colors line-clamp-1 mb-1">
                      {album.name}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4 h-10">
                      {album.description || "No description"}
                    </p>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <div className="flex items-center gap-1.5">
                          <ImageIcon className="h-3.5 w-3.5" />
                          <span>{album.photoCount || 0} photos</span>
                        </div>
                        <span>{progress}% identified</span>
                      </div>
                      <Progress value={progress} className="h-1.5 bg-muted" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            )
          })
        )}
      </div>
    </div>
  );
}
