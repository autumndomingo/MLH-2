import { useParams, Link, useLocation } from "wouter";
import { useGetPhoto, getGetPhotoQueryKey, useUpdatePhoto, useDeletePhoto, useAddIdentification, useTagPersonInPhoto, useListPeople, getListPeopleQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, MapPin, ArrowLeft, BookOpen, Users, Info, CheckCircle2, MessageSquare, Trash2, Tag, Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";

const idFormSchema = z.object({
  contributorName: z.string().min(1, "Name is required"),
  content: z.string().min(1, "Memory or context is required"),
  type: z.enum(["person_name", "location", "story", "date", "general"]),
});

const tagFormSchema = z.object({
  personId: z.string().min(1, "Person is required"),
});

export default function PhotoDetail() {
  const params = useParams();
  const id = Number(params.id);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [idDialogOpen, setIdDialogOpen] = useState(false);
  const [tagDialogOpen, setTagDialogOpen] = useState(false);

  const { data: photo, isLoading } = useGetPhoto(id, {
    query: { enabled: !!id, queryKey: getGetPhotoQueryKey(id) }
  });

  const { data: people } = useListPeople({
    query: { queryKey: getListPeopleQueryKey() }
  });

  const updatePhoto = useUpdatePhoto();
  const deletePhoto = useDeletePhoto();
  const addIdentification = useAddIdentification();
  const tagPerson = useTagPersonInPhoto();

  const idForm = useForm<z.infer<typeof idFormSchema>>({
    resolver: zodResolver(idFormSchema),
    defaultValues: { contributorName: "", content: "", type: "story" },
  });

  const tagForm = useForm<z.infer<typeof tagFormSchema>>({
    resolver: zodResolver(tagFormSchema),
    defaultValues: { personId: "" },
  });

  const handleMarkIdentified = () => {
    updatePhoto.mutate(
      { id, data: { needsIdentification: false } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetPhotoQueryKey(id) });
          toast({ title: "Updated", description: "Photograph marked as identified." });
        }
      }
    );
  };

  const handleDelete = () => {
    if (window.confirm("Are you sure you want to delete this photograph? This cannot be undone.")) {
      deletePhoto.mutate({ id }, {
        onSuccess: () => {
          toast({ title: "Deleted", description: "Photograph removed from archive." });
          setLocation("/photos");
        }
      });
    }
  };

  const onAddId = (values: z.infer<typeof idFormSchema>) => {
    addIdentification.mutate(
      { id, data: values },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetPhotoQueryKey(id) });
          setIdDialogOpen(false);
          idForm.reset();
          toast({ title: "Context added", description: "Thank you for sharing your memory." });
        }
      }
    );
  };

  const onTagPerson = (values: z.infer<typeof tagFormSchema>) => {
    tagPerson.mutate(
      { id, data: { personId: parseInt(values.personId, 10) } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetPhotoQueryKey(id) });
          setTagDialogOpen(false);
          tagForm.reset();
          toast({ title: "Person tagged", description: "Family member linked to photograph." });
        }
      }
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-32" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Skeleton className="w-full aspect-[4/3] rounded-lg" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!photo) return null;

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <Link href={photo.albumId ? `/albums/${photo.albumId}` : "/photos"}>
          <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground">
            <ArrowLeft className="h-4 w-4" />
            Back to {photo.albumName || "Photographs"}
          </Button>
        </Link>
        <Button variant="ghost" size="sm" onClick={handleDelete} className="text-destructive hover:text-destructive hover:bg-destructive/10">
          <Trash2 className="h-4 w-4 mr-2" /> Delete
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Main Photo View */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-card border border-border/50 rounded-lg p-3 sm:p-6 shadow-sm flex items-center justify-center relative group">
            <div className="relative inline-block max-w-full">
              <div className="absolute inset-0 bg-white/5 border border-white/20 pointer-events-none m-2" />
              <img 
                src={photo.imageUrl} 
                alt={photo.title || "Family photograph"} 
                className="max-h-[70vh] w-auto object-contain rounded shadow-md sepia-[0.15]"
              />
            </div>
            
            {photo.needsIdentification && (
              <div className="absolute top-6 right-6 z-10">
                <Badge className="bg-amber-500 hover:bg-amber-600 text-white shadow-sm px-3 py-1 text-sm font-medium border-none">
                  Needs Identification
                </Badge>
              </div>
            )}
          </div>
          
          <div className="flex items-center justify-between">
            <h1 className="font-serif text-2xl md:text-3xl font-medium text-primary">
              {photo.title || "Untitled Photograph"}
            </h1>
            
            {photo.needsIdentification && (
              <Button 
                variant="outline" 
                onClick={handleMarkIdentified}
                disabled={updatePhoto.isPending}
                className="gap-2 text-green-700 hover:text-green-800 hover:bg-green-50 border-green-200"
              >
                <CheckCircle2 className="h-4 w-4" />
                Mark as Identified
              </Button>
            )}
          </div>
          
          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground border-b border-border/50 pb-6">
            {photo.approximateYear && (
              <div className="flex items-center gap-1.5">
                <Clock className="h-4 w-4" />
                <span>{photo.approximateYear}</span>
              </div>
            )}
            {photo.location && (
              <div className="flex items-center gap-1.5">
                <MapPin className="h-4 w-4" />
                <span>{photo.location}</span>
              </div>
            )}
            {photo.albumName && (
              <div className="flex items-center gap-1.5">
                <BookOpen className="h-4 w-4" />
                <Link href={`/albums/${photo.albumId}`} className="hover:text-primary hover:underline">
                  {photo.albumName}
                </Link>
              </div>
            )}
          </div>

          {photo.notes && (
            <div className="bg-[#fdf8f5] p-6 rounded-lg border border-amber-100/50">
              <h3 className="font-serif text-lg font-medium text-amber-900 flex items-center gap-2 mb-3">
                <Info className="h-4 w-4" /> Original Notes
              </h3>
              <p className="text-amber-800/80 leading-relaxed italic whitespace-pre-wrap">
                {photo.notes}
              </p>
            </div>
          )}
        </div>

        {/* Sidebar: Details & Context */}
        <div className="space-y-6">
          <Card className="border-border/50 shadow-sm bg-card">
            <CardHeader className="pb-3 border-b border-border/50 flex flex-row items-center justify-between">
              <CardTitle className="font-serif text-lg flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" /> People in Photo
              </CardTitle>
              <Dialog open={tagDialogOpen} onOpenChange={setTagDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-primary">
                    <Tag className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle className="font-serif">Tag a Family Member</DialogTitle>
                  </DialogHeader>
                  <Form {...tagForm}>
                    <form onSubmit={tagForm.handleSubmit(onTagPerson)} className="space-y-4">
                      <FormField
                        control={tagForm.control}
                        name="personId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Person</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a person" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {people?.map((p) => (
                                  <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" disabled={tagPerson.isPending} className="w-full">
                        Tag Person
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent className="p-4">
              {photo.people?.length > 0 ? (
                <ul className="space-y-3">
                  {photo.people.map(person => (
                    <li key={person.id}>
                      <Link href={`/people/${person.id}`} className="flex flex-col group">
                        <span className="font-medium text-foreground group-hover:text-primary transition-colors">
                          {person.name}
                        </span>
                        {person.relationship && (
                          <span className="text-xs text-muted-foreground">{person.relationship}</span>
                        )}
                      </Link>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No people tagged yet.
                </p>
              )}
            </CardContent>
          </Card>

          <Card className="border-border/50 shadow-sm bg-card flex flex-col max-h-[600px]">
            <CardHeader className="pb-3 border-b border-border/50">
              <CardTitle className="font-serif text-lg flex items-center gap-2">
                <MessageSquare className="h-5 w-5 text-primary" /> Memories & Context
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 overflow-y-auto flex-1">
              {photo.identifications?.length > 0 ? (
                <ul className="divide-y divide-border/50">
                  {photo.identifications.map(id => (
                    <li key={id.id} className="p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-sm text-foreground">{id.contributorName}</span>
                        <span className="text-[10px] text-muted-foreground uppercase tracking-wide">
                          {format(new Date(id.createdAt), "MMM d, yyyy")}
                        </span>
                      </div>
                      <Badge variant="outline" className="text-[10px] py-0 h-4 bg-muted/50 border-none font-normal">
                        {id.type.replace('_', ' ')}
                      </Badge>
                      <p className="text-sm text-foreground leading-relaxed mt-1">
                        {id.content}
                      </p>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">
                  No context added yet. Be the first to share a memory.
                </p>
              )}
            </CardContent>
            
            <div className="p-4 border-t border-border/50 bg-muted/20">
              <Dialog open={idDialogOpen} onOpenChange={setIdDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full bg-background border-dashed border-primary/30 text-primary">
                    <Plus className="h-4 w-4 mr-2" /> Add Context or Memory
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle className="font-serif">Share a Memory</DialogTitle>
                  </DialogHeader>
                  <Form {...idForm}>
                    <form onSubmit={idForm.handleSubmit(onAddId)} className="space-y-4">
                      <FormField
                        control={idForm.control}
                        name="contributorName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Your Name</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g. Tita Maria" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={idForm.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Type of Information</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="story">Story</SelectItem>
                                <SelectItem value="person_name">Person's Name</SelectItem>
                                <SelectItem value="location">Location</SelectItem>
                                <SelectItem value="date">Date</SelectItem>
                                <SelectItem value="general">General Note</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={idForm.control}
                        name="content"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Memory or Context</FormLabel>
                            <FormControl>
                              <Textarea placeholder="I remember this was taken during..." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button type="submit" disabled={addIdentification.isPending} className="w-full">
                        Add Memory
                      </Button>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
