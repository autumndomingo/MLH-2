import { useState } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { useListPhotos, getListPhotosQueryKey, useCreatePhoto, useListAlbums, getListAlbumsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ImageIcon, Clock, MapPin, Filter, X, Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  imageUrl: z.string().url("Must be a valid URL"),
  albumId: z.string().min(1, "Album is required"),
  title: z.string().optional(),
  approximateYear: z.string().optional(),
  location: z.string().optional(),
  notes: z.string().optional(),
  needsIdentification: z.boolean().default(false),
});

export default function Photos() {
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const needsIdentification = searchParams.get("needsIdentification") === "true";
  const decade = searchParams.get("decade") || undefined;
  
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [open, setOpen] = useState(false);

  const { data: photos, isLoading } = useListPhotos(
    { needsIdentification, decade },
    { query: { queryKey: getListPhotosQueryKey({ needsIdentification, decade }) } }
  );

  const { data: albums } = useListAlbums({
    query: { queryKey: getListAlbumsQueryKey() }
  });

  const createPhoto = useCreatePhoto();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      imageUrl: "",
      albumId: "",
      title: "",
      approximateYear: "",
      location: "",
      notes: "",
      needsIdentification: false,
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    createPhoto.mutate(
      { data: { ...values, albumId: parseInt(values.albumId, 10) } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListPhotosQueryKey() });
          setOpen(false);
          form.reset();
          toast({ title: "Photograph added", description: "Successfully added to the archive." });
        }
      }
    );
  };

  const clearFilters = () => {
    setLocation("/photos");
  };

  const toggleNeedsId = () => {
    const params = new URLSearchParams(searchString);
    if (needsIdentification) {
      params.delete("needsIdentification");
    } else {
      params.set("needsIdentification", "true");
    }
    setLocation(`/photos?${params.toString()}`);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-border/50 pb-6">
        <div>
          <h1 className="font-serif text-3xl font-medium tracking-tight text-primary">Photographs</h1>
          <p className="text-muted-foreground mt-2">Browse the entire family archive.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex items-center gap-3 overflow-x-auto pb-2 md:pb-0">
            <div className="flex items-center gap-2 mr-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium text-muted-foreground">Filters:</span>
            </div>
            
            <Button 
              variant={needsIdentification ? "default" : "outline"} 
              size="sm" 
              onClick={toggleNeedsId}
              className="rounded-full border-amber-200"
            >
              Needs Context
            </Button>
            
            {(needsIdentification || decade) && (
              <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground">
                <X className="h-4 w-4 mr-1" /> Clear
              </Button>
            )}
          </div>

          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 shrink-0">
                <Plus className="h-4 w-4" /> Add Photograph
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md overflow-y-auto max-h-[90vh]">
              <DialogHeader>
                <DialogTitle className="font-serif">Add to Archive</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Image URL</FormLabel>
                        <FormControl>
                          <Input placeholder="https://..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="albumId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Album</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select an album" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {albums?.map((album) => (
                              <SelectItem key={album.id} value={album.id.toString()}>{album.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Family Picnic at the Beach" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="approximateYear"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Year (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. 1980s or 1985" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Manila, Philippines" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes (Optional)</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Any context or story behind this photo..." {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="needsIdentification"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            Needs Identification
                          </FormLabel>
                          <p className="text-xs text-muted-foreground">
                            Flag this photo so family members can help add context.
                          </p>
                        </div>
                      </FormItem>
                    )}
                  />
                  <Button type="submit" disabled={createPhoto.isPending} className="w-full">
                    Upload Photograph
                  </Button>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="columns-2 md:columns-3 lg:columns-4 gap-4 space-y-4">
        {isLoading ? (
          Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="break-inside-avoid mb-4">
              <Skeleton className="w-full" style={{ height: `${Math.floor(Math.random() * 150) + 150}px` }} />
            </div>
          ))
        ) : photos?.length === 0 ? (
          <div className="col-span-full py-24 text-center border-2 border-dashed border-border rounded-lg bg-card/50">
            <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="font-serif text-lg font-medium text-foreground mb-1">No photographs found</h3>
            <p className="text-muted-foreground text-sm">Try adjusting your filters.</p>
          </div>
        ) : (
          photos?.map((photo, idx) => (
            <Link key={photo.id} href={`/photos/${photo.id}`}>
              <div className="break-inside-avoid mb-4 group cursor-pointer relative overflow-hidden rounded-md bg-muted">
                <div className="absolute inset-2 bg-white/10 z-10 border border-white/20 pointer-events-none" />
                <img 
                  src={photo.imageUrl} 
                  alt={photo.title || "Untitled photograph"} 
                  className="w-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out sepia-[0.3]"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                
                {photo.needsIdentification && (
                  <div className="absolute top-3 right-3 bg-amber-500/90 backdrop-blur-sm text-white text-[10px] font-medium px-2 py-0.5 rounded shadow-sm z-20">
                    Needs ID
                  </div>
                )}
                
                <div className="absolute bottom-0 left-0 w-full p-4 transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 z-20 flex flex-col gap-1.5 text-white">
                  {photo.title && (
                    <p className="text-sm font-medium line-clamp-1">{photo.title}</p>
                  )}
                  <div className="flex flex-wrap items-center gap-3 text-xs opacity-90">
                    {photo.approximateYear && (
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{photo.approximateYear}</span>
                      </div>
                    )}
                    {photo.location && (
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        <span className="truncate">{photo.location}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
