import { useParams, Link } from "wouter";
import { useGetPerson, getGetPersonQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Clock, MapPin, Info } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function PersonDetail() {
  const params = useParams();
  const id = Number(params.id);

  const { data: person, isLoading } = useGetPerson(id, {
    query: { enabled: !!id, queryKey: getGetPersonQueryKey(id) }
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <Link href="/people">
        <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground -ml-2 mb-2">
          <ArrowLeft className="h-4 w-4" />
          Back to People
        </Button>
      </Link>

      {isLoading ? (
        <div className="space-y-8">
          <div className="flex items-center gap-6">
            <Skeleton className="h-24 w-24 rounded-full" />
            <div className="space-y-3 flex-1">
              <Skeleton className="h-8 w-64" />
              <Skeleton className="h-4 w-48" />
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Skeleton className="w-full aspect-square" />
            <Skeleton className="w-full aspect-square" />
            <Skeleton className="w-full aspect-square" />
            <Skeleton className="w-full aspect-square" />
          </div>
        </div>
      ) : person ? (
        <>
          <div className="flex flex-col md:flex-row md:items-center gap-6 bg-card border border-border/50 rounded-lg p-6 md:p-8 shadow-sm">
            <div className="h-20 w-20 md:h-24 md:w-24 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <span className="font-serif font-medium text-3xl md:text-4xl">
                {person.name.charAt(0).toUpperCase()}
              </span>
            </div>
            
            <div className="flex-1">
              <h1 className="font-serif text-3xl md:text-4xl font-medium tracking-tight text-primary">
                {person.name}
              </h1>
              
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 mt-3 text-muted-foreground text-sm">
                {person.relationship && (
                  <span className="font-medium text-foreground bg-secondary px-2.5 py-0.5 rounded-full text-xs">
                    {person.relationship}
                  </span>
                )}
                
                {(person.birthYear || person.deathYear) && (
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4" />
                    <span>
                      {person.birthYear ? person.birthYear : "?"} - {person.deathYear ? person.deathYear : "Present"}
                    </span>
                  </div>
                )}
              </div>
              
              {person.notes && (
                <div className="mt-4 text-sm text-foreground/80 leading-relaxed flex items-start gap-2 max-w-3xl">
                  <Info className="h-4 w-4 shrink-0 mt-0.5 text-muted-foreground" />
                  <p>{person.notes}</p>
                </div>
              )}
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="font-serif text-2xl font-medium">Appears in {person.photos?.length || 0} Photographs</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {person.photos?.map((photo, idx) => (
                <Link key={photo.id} href={`/photos/${photo.id}`}>
                  <Card 
                    className="overflow-hidden border-border/50 group cursor-pointer hover:shadow-md transition-all duration-300 bg-card rounded-md"
                    style={{ animationDelay: `${idx * 50}ms` }}
                  >
                    <div className="aspect-square bg-muted relative overflow-hidden flex items-center justify-center p-2">
                      <div className="absolute inset-2 bg-white/10 z-10 border border-white/20 pointer-events-none" />
                      <img 
                        src={photo.imageUrl} 
                        alt={photo.title || "Untitled photograph"} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out sepia-[0.3]"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                      
                      <div className="absolute bottom-0 left-0 w-full p-4 transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 z-20 flex flex-col gap-1.5 text-white">
                        {photo.approximateYear && (
                          <div className="flex items-center gap-1.5 text-xs">
                            <Clock className="h-3.5 w-3.5" />
                            <span>{photo.approximateYear}</span>
                          </div>
                        )}
                        {photo.location && (
                          <div className="flex items-center gap-1.5 text-xs">
                            <MapPin className="h-3.5 w-3.5" />
                            <span className="truncate">{photo.location}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}
