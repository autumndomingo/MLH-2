import { useState } from "react";
import { Link } from "wouter";
import { useListPeople, getListPeopleQueryKey, useCreatePerson } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Users, ImageIcon, Plus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  relationship: z.string().optional(),
  birthYear: z.string().optional(),
  deathYear: z.string().optional(),
  notes: z.string().optional(),
});

export default function People() {
  const { data: people, isLoading } = useListPeople({
    query: { queryKey: getListPeopleQueryKey() }
  });

  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const createPerson = useCreatePerson();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      relationship: "",
      birthYear: "",
      deathYear: "",
      notes: "",
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    const payload = {
      name: values.name,
      relationship: values.relationship,
      birthYear: values.birthYear ? parseInt(values.birthYear, 10) : undefined,
      deathYear: values.deathYear ? parseInt(values.deathYear, 10) : undefined,
      notes: values.notes,
    };
    
    createPerson.mutate(
      { data: payload },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListPeopleQueryKey() });
          setOpen(false);
          form.reset();
          toast({ title: "Person added", description: "Family member successfully added." });
        }
      }
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-border/50 pb-6">
        <div>
          <h1 className="font-serif text-3xl font-medium tracking-tight text-primary">Family & People</h1>
          <p className="text-muted-foreground mt-2">The faces that make up our history.</p>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shrink-0">
              <Plus className="h-4 w-4" /> Add Person
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-serif">Add Family Member</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Maria Santos" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="relationship"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Relationship (Optional)</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Grandmother" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="birthYear"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Birth Year (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. 1930" type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="deathYear"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Death Year (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. 2015" type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Brief biography or notes..." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={createPerson.isPending} className="w-full">
                  Add to Archive
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {isLoading ? (
          Array.from({ length: 8 }).map((_, i) => (
            <Card key={i} className="border-border/50 shadow-sm">
              <CardContent className="p-6 flex items-center gap-4">
                <Skeleton className="h-12 w-12 rounded-full shrink-0" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : people?.length === 0 ? (
          <div className="col-span-full py-16 text-center border-2 border-dashed border-border rounded-lg bg-card/50">
            <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
            <h3 className="font-serif text-lg font-medium text-foreground mb-1">No People Identified</h3>
            <p className="text-muted-foreground text-sm">Start adding family members to build the archive.</p>
          </div>
        ) : (
          people?.map((person) => (
            <Link key={person.id} href={`/people/${person.id}`}>
              <Card className="border-border/50 shadow-sm hover:border-primary/30 hover:shadow-md transition-all cursor-pointer bg-card group">
                <CardContent className="p-5 flex items-center gap-4">
                  <div className="h-12 w-12 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                    <span className="font-serif font-medium text-lg">
                      {person.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium text-foreground truncate group-hover:text-primary transition-colors">
                      {person.name}
                    </h3>
                    {person.relationship && (
                      <p className="text-xs text-muted-foreground truncate mt-0.5">
                        {person.relationship}
                      </p>
                    )}
                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-muted-foreground font-medium uppercase tracking-wider">
                      <ImageIcon className="h-3 w-3" />
                      <span>{person.photoCount || 0} Photos</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        )}
      </div>
    </div>
  );
}
