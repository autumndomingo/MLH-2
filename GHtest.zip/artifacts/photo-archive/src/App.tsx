import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Albums from "@/pages/albums/index";
import AlbumDetail from "@/pages/albums/detail";
import Photos from "@/pages/photos/index";
import PhotoDetail from "@/pages/photos/detail";
import People from "@/pages/people/index";
import PersonDetail from "@/pages/people/detail";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/albums" component={Albums} />
        <Route path="/albums/:id" component={AlbumDetail} />
        <Route path="/photos" component={Photos} />
        <Route path="/photos/:id" component={PhotoDetail} />
        <Route path="/people" component={People} />
        <Route path="/people/:id" component={PersonDetail} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
