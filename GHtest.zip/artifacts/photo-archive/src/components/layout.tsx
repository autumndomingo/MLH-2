import { Link, useLocation } from "wouter";
import { BookOpen, Users, Image as ImageIcon, Home, Menu, Search, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  const navigation = [
    { name: "Archive", href: "/", icon: Home },
    { name: "Albums", href: "/albums", icon: BookOpen },
    { name: "Photographs", href: "/photos", icon: ImageIcon },
    { name: "Family & People", href: "/people", icon: Users },
  ];

  const NavLinks = () => (
    <>
      <div className="flex flex-col space-y-1 py-4">
        {navigation.map((item) => {
          const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
          return (
            <Link key={item.name} href={item.href}>
              <Button
                variant={isActive ? "secondary" : "ghost"}
                className={`justify-start w-full gap-3 ${
                  isActive ? "bg-primary text-primary-foreground font-medium" : "text-muted-foreground hover:text-foreground"
                }`}
                onClick={() => setOpen(false)}
              >
                <item.icon className="h-4 w-4" />
                {item.name}
              </Button>
            </Link>
          );
        })}
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-background flex w-full font-sans text-foreground">
      {/* Sidebar for Desktop */}
      <aside className="hidden md:flex w-64 flex-col border-r border-border bg-sidebar shrink-0">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <Link href="/" className="flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-primary" />
            <span className="font-serif text-xl font-bold tracking-tight text-primary">Alaala</span>
          </Link>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-6">
          <NavLinks />
        </div>
        <div className="p-4 border-t border-border">
          <div className="rounded-lg bg-card border border-border p-4 shadow-sm text-center">
            <h3 className="font-serif font-semibold text-sm mb-1">Preserve the Past</h3>
            <p className="text-xs text-muted-foreground">Every photo holds a story waiting to be told.</p>
          </div>
        </div>
      </aside>

      {/* Mobile Header & Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 flex md:hidden items-center justify-between px-4 border-b border-border bg-sidebar">
          <Link href="/" className="flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-primary" />
            <span className="font-serif text-lg font-bold tracking-tight text-primary">Alaala</span>
          </Link>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Open Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[280px] p-0 bg-sidebar border-border">
              <div className="h-16 flex items-center px-6 border-b border-border">
                <span className="font-serif text-xl font-bold tracking-tight text-primary">Alaala</span>
              </div>
              <div className="px-4 py-2">
                <NavLinks />
              </div>
            </SheetContent>
          </Sheet>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-8 lg:p-12">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
