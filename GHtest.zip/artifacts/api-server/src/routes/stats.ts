import { Router } from "express";
import { db } from "@workspace/db";
import { photosTable, albumsTable, peopleTable, identificationsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";

const router = Router();

router.get("/stats", async (req, res) => {
  const [totalPhotosRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(photosTable);

  const [identifiedRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(photosTable)
    .where(eq(photosTable.needsIdentification, false));

  const [albumsRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(albumsTable);

  const [peopleRow] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(peopleTable);

  const totalPhotos = totalPhotosRow?.count ?? 0;
  const identifiedPhotos = identifiedRow?.count ?? 0;
  const unidentifiedPhotos = totalPhotos - identifiedPhotos;

  const recentActivity = await db
    .select()
    .from(identificationsTable)
    .orderBy(sql`${identificationsTable.createdAt} DESC`)
    .limit(10);

  res.json({
    totalPhotos,
    identifiedPhotos,
    unidentifiedPhotos,
    totalAlbums: albumsRow?.count ?? 0,
    totalPeople: peopleRow?.count ?? 0,
    recentActivity: recentActivity.map((i) => ({
      id: i.id,
      photoId: i.photoId,
      contributorName: i.contributorName,
      content: i.content,
      type: i.type,
      createdAt: i.createdAt.toISOString(),
    })),
  });
});

export default router;
