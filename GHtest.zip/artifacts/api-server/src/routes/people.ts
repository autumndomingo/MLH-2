import { Router } from "express";
import { db } from "@workspace/db";
import { peopleTable, photoPeopleTable, photosTable, albumsTable, identificationsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { CreatePersonBody } from "@workspace/api-zod";

const router = Router();

router.get("/people", async (req, res) => {
  const people = await db.select().from(peopleTable).orderBy(peopleTable.name);

  const result = await Promise.all(
    people.map(async (person) => {
      const [pc] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(photoPeopleTable)
        .where(eq(photoPeopleTable.personId, person.id));

      return {
        id: person.id,
        name: person.name,
        relationship: person.relationship,
        birthYear: person.birthYear,
        deathYear: person.deathYear,
        notes: person.notes,
        photoCount: pc?.count ?? 0,
        createdAt: person.createdAt.toISOString(),
      };
    })
  );

  res.json(result);
});

router.post("/people", async (req, res) => {
  const parsed = CreatePersonBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const [person] = await db
    .insert(peopleTable)
    .values({
      name: parsed.data.name,
      relationship: parsed.data.relationship,
      birthYear: parsed.data.birthYear,
      deathYear: parsed.data.deathYear,
      notes: parsed.data.notes,
    })
    .returning();

  res.status(201).json({
    id: person.id,
    name: person.name,
    relationship: person.relationship,
    birthYear: person.birthYear,
    deathYear: person.deathYear,
    notes: person.notes,
    photoCount: 0,
    createdAt: person.createdAt.toISOString(),
  });
});

router.get("/people/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const [person] = await db.select().from(peopleTable).where(eq(peopleTable.id, id));
  if (!person) {
    res.status(404).json({ error: "Person not found" });
    return;
  }

  const photoRows = await db
    .select({ photo: photosTable, albumName: albumsTable.name })
    .from(photoPeopleTable)
    .innerJoin(photosTable, eq(photoPeopleTable.photoId, photosTable.id))
    .leftJoin(albumsTable, eq(photosTable.albumId, albumsTable.id))
    .where(eq(photoPeopleTable.personId, id));

  const photos = await Promise.all(
    photoRows.map(async ({ photo, albumName }) => {
      const [idCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(identificationsTable)
        .where(eq(identificationsTable.photoId, photo.id));

      const [pCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(photoPeopleTable)
        .where(eq(photoPeopleTable.photoId, photo.id));

      return {
        id: photo.id,
        albumId: photo.albumId,
        albumName: albumName ?? null,
        imageUrl: photo.imageUrl,
        title: photo.title,
        approximateYear: photo.approximateYear,
        location: photo.location,
        notes: photo.notes,
        needsIdentification: photo.needsIdentification,
        identificationCount: idCount?.count ?? 0,
        peopleCount: pCount?.count ?? 0,
        createdAt: photo.createdAt.toISOString(),
      };
    })
  );

  res.json({
    id: person.id,
    name: person.name,
    relationship: person.relationship,
    birthYear: person.birthYear,
    deathYear: person.deathYear,
    notes: person.notes,
    createdAt: person.createdAt.toISOString(),
    photos,
  });
});

export default router;
