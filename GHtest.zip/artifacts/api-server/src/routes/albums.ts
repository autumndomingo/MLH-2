import { Router } from "express";
import { db, albumsTable, photosTable, identificationsTable, photoPeopleTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { CreateAlbumBody } from "@workspace/api-zod";

const router = Router();

router.get("/albums", async (req, res) => {
  const albums = await db.select().from(albumsTable).orderBy(albumsTable.name);

  const result = await Promise.all(
    albums.map(async (album) => {
      const photos = await db
        .select()
        .from(photosTable)
        .where(eq(photosTable.albumId, album.id));

      const coverPhoto = photos[0];
      const identifiedCount = photos.filter((p) => !p.needsIdentification).length;

      return {
        id: album.id,
        name: album.name,
        description: album.description,
        coverPhotoUrl: coverPhoto?.imageUrl ?? null,
        photoCount: photos.length,
        identifiedCount,
        createdAt: album.createdAt.toISOString(),
      };
    })
  );

  res.json(result);
});

router.post("/albums", async (req, res) => {
  const parsed = CreateAlbumBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const [album] = await db
    .insert(albumsTable)
    .values({ name: parsed.data.name, description: parsed.data.description })
    .returning();

  res.status(201).json({
    id: album.id,
    name: album.name,
    description: album.description,
    coverPhotoUrl: null,
    photoCount: 0,
    identifiedCount: 0,
    createdAt: album.createdAt.toISOString(),
  });
});

router.get("/albums/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const [album] = await db.select().from(albumsTable).where(eq(albumsTable.id, id));
  if (!album) {
    res.status(404).json({ error: "Album not found" });
    return;
  }

  const photos = await db.select().from(photosTable).where(eq(photosTable.albumId, id)).orderBy(photosTable.createdAt);

  const photosWithCounts = await Promise.all(
    photos.map(async (photo) => {
      const [idCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(identificationsTable)
        .where(eq(identificationsTable.photoId, photo.id));

      const [peopleCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(photoPeopleTable)
        .where(eq(photoPeopleTable.photoId, photo.id));

      return {
        id: photo.id,
        albumId: photo.albumId,
        albumName: album.name,
        imageUrl: photo.imageUrl,
        title: photo.title,
        approximateYear: photo.approximateYear,
        location: photo.location,
        notes: photo.notes,
        needsIdentification: photo.needsIdentification,
        identificationCount: idCount?.count ?? 0,
        peopleCount: peopleCount?.count ?? 0,
        createdAt: photo.createdAt.toISOString(),
      };
    })
  );

  res.json({
    id: album.id,
    name: album.name,
    description: album.description,
    coverPhotoUrl: photos[0]?.imageUrl ?? null,
    createdAt: album.createdAt.toISOString(),
    photos: photosWithCounts,
  });
});

export default router;
