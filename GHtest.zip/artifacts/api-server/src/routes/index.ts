import { Router, type IRouter } from "express";
import healthRouter from "./health";
import albumsRouter from "./albums";
import photosRouter from "./photos";
import peopleRouter from "./people";
import statsRouter from "./stats";

const router: IRouter = Router();

router.use(healthRouter);
router.use(albumsRouter);
router.use(photosRouter);
router.use(peopleRouter);
router.use(statsRouter);

export default router;
