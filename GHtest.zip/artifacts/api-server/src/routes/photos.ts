import { Router } from "express";
import { db } from "@workspace/db";
import {
  photosTable,
  albumsTable,
  identificationsTable,
  photoPeopleTable,
  peopleTable,
} from "@workspace/db";
import { eq, sql, and } from "drizzle-orm";
import { CreatePhotoBody, UpdatePhotoBody, TagPersonInPhotoBody } from "@workspace/api-zod";

const router = Router();

router.get("/photos", async (req, res) => {
  const { albumId, needsIdentification, decade, personId } = req.query;

  let baseQuery = db
    .select({
      photo: photosTable,
      albumName: albumsTable.name,
    })
    .from(photosTable)
    .leftJoin(albumsTable, eq(photosTable.albumId, albumsTable.id));

  const conditions = [];

  if (albumId) {
    conditions.push(eq(photosTable.albumId, parseInt(albumId as string)));
  }

  if (needsIdentification === "true") {
    conditions.push(eq(photosTable.needsIdentification, true));
  } else if (needsIdentification === "false") {
    conditions.push(eq(photosTable.needsIdentification, false));
  }

  if (decade) {
    conditions.push(sql`${photosTable.approximateYear} LIKE ${`${decade}%`}`);
  }

  let photos: { photo: typeof photosTable.$inferSelect; albumName: string | null }[];

  if (conditions.length > 0) {
    photos = await baseQuery.where(and(...conditions)).orderBy(photosTable.createdAt);
  } else {
    photos = await baseQuery.orderBy(photosTable.createdAt);
  }

  if (personId) {
    const pid = parseInt(personId as string);
    const personPhotoIds = await db
      .select({ photoId: photoPeopleTable.photoId })
      .from(photoPeopleTable)
      .where(eq(photoPeopleTable.personId, pid));
    const ids = new Set(personPhotoIds.map((p) => p.photoId));
    photos = photos.filter((p) => ids.has(p.photo.id));
  }

  const result = await Promise.all(
    photos.map(async ({ photo, albumName }) => {
      const [idCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(identificationsTable)
        .where(eq(identificationsTable.photoId, photo.id));

      const [peopleCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(photoPeopleTable)
        .where(eq(photoPeopleTable.photoId, photo.id));

      return {
        id: photo.id,
        albumId: photo.albumId,
        albumName: albumName ?? null,
        imageUrl: photo.imageUrl,
        title: photo.title,
        approximateYear: photo.approximateYear,
        location: photo.location,
        notes: photo.notes,
        needsIdentification: photo.needsIdentification,
        identificationCount: idCount?.count ?? 0,
        peopleCount: peopleCount?.count ?? 0,
        createdAt: photo.createdAt.toISOString(),
      };
    })
  );

  res.json(result);
});

router.post("/photos", async (req, res) => {
  const parsed = CreatePhotoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const [photo] = await db
    .insert(photosTable)
    .values({
      albumId: parsed.data.albumId,
      imageUrl: parsed.data.imageUrl,
      title: parsed.data.title,
      approximateYear: parsed.data.approximateYear,
      location: parsed.data.location,
      notes: parsed.data.notes,
      needsIdentification: parsed.data.needsIdentification ?? true,
    })
    .returning();

  const [album] = await db.select().from(albumsTable).where(eq(albumsTable.id, photo.albumId));

  res.status(201).json({
    id: photo.id,
    albumId: photo.albumId,
    albumName: album?.name ?? null,
    imageUrl: photo.imageUrl,
    title: photo.title,
    approximateYear: photo.approximateYear,
    location: photo.location,
    notes: photo.notes,
    needsIdentification: photo.needsIdentification,
    identificationCount: 0,
    peopleCount: 0,
    createdAt: photo.createdAt.toISOString(),
  });
});

router.get("/photos/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const [photo] = await db
    .select({ photo: photosTable, albumName: albumsTable.name })
    .from(photosTable)
    .leftJoin(albumsTable, eq(photosTable.albumId, albumsTable.id))
    .where(eq(photosTable.id, id));

  if (!photo) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }

  const identifications = await db
    .select()
    .from(identificationsTable)
    .where(eq(identificationsTable.photoId, id))
    .orderBy(identificationsTable.createdAt);

  const photoPeople = await db
    .select({ person: peopleTable })
    .from(photoPeopleTable)
    .innerJoin(peopleTable, eq(photoPeopleTable.personId, peopleTable.id))
    .where(eq(photoPeopleTable.photoId, id));

  const peopleWithCounts = await Promise.all(
    photoPeople.map(async ({ person }) => {
      const [pc] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(photoPeopleTable)
        .where(eq(photoPeopleTable.personId, person.id));
      return {
        id: person.id,
        name: person.name,
        relationship: person.relationship,
        birthYear: person.birthYear,
        deathYear: person.deathYear,
        notes: person.notes,
        photoCount: pc?.count ?? 0,
        createdAt: person.createdAt.toISOString(),
      };
    })
  );

  res.json({
    id: photo.photo.id,
    albumId: photo.photo.albumId,
    albumName: photo.albumName ?? null,
    imageUrl: photo.photo.imageUrl,
    title: photo.photo.title,
    approximateYear: photo.photo.approximateYear,
    location: photo.photo.location,
    notes: photo.photo.notes,
    needsIdentification: photo.photo.needsIdentification,
    createdAt: photo.photo.createdAt.toISOString(),
    identifications: identifications.map((i) => ({
      id: i.id,
      photoId: i.photoId,
      contributorName: i.contributorName,
      content: i.content,
      type: i.type,
      createdAt: i.createdAt.toISOString(),
    })),
    people: peopleWithCounts,
  });
});

router.patch("/photos/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const parsed = UpdatePhotoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const [photo] = await db
    .update(photosTable)
    .set(parsed.data)
    .where(eq(photosTable.id, id))
    .returning();

  if (!photo) {
    res.status(404).json({ error: "Photo not found" });
    return;
  }

  const [album] = await db.select().from(albumsTable).where(eq(albumsTable.id, photo.albumId));
  const [idCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(identificationsTable)
    .where(eq(identificationsTable.photoId, photo.id));
  const [pCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(photoPeopleTable)
    .where(eq(photoPeopleTable.photoId, photo.id));

  res.json({
    id: photo.id,
    albumId: photo.albumId,
    albumName: album?.name ?? null,
    imageUrl: photo.imageUrl,
    title: photo.title,
    approximateYear: photo.approximateYear,
    location: photo.location,
    notes: photo.notes,
    needsIdentification: photo.needsIdentification,
    identificationCount: idCount?.count ?? 0,
    peopleCount: pCount?.count ?? 0,
    createdAt: photo.createdAt.toISOString(),
  });
});

router.delete("/photos/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  await db.delete(photosTable).where(eq(photosTable.id, id));
  res.status(204).send();
});

router.get("/photos/:id/identifications", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const identifications = await db
    .select()
    .from(identificationsTable)
    .where(eq(identificationsTable.photoId, id))
    .orderBy(identificationsTable.createdAt);

  res.json(
    identifications.map((i) => ({
      id: i.id,
      photoId: i.photoId,
      contributorName: i.contributorName,
      content: i.content,
      type: i.type,
      createdAt: i.createdAt.toISOString(),
    }))
  );
});

router.post("/photos/:id/identifications", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid id" });
    return;
  }

  const { AddIdentificationBody } = await import("@workspace/api-zod");
  const parsed = AddIdentificationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const [identification] = await db
    .insert(identificationsTable)
    .values({
      photoId: id,
      contributorName: parsed.data.contributorName,
      content: parsed.data.content,
      type: parsed.data.type as "person_name" | "location" | "story" | "date" | "general",
    })
    .returning();

  res.status(201).json({
    id: identification.id,
    photoId: identification.photoId,
    contributorName: identification.contributorName,
    content: identification.content,
    type: identification.type,
    createdAt: identification.createdAt.toISOString(),
  });
});

router.post("/photos/:photoId/people", async (req, res) => {
  const photoId = parseInt(req.params.photoId);
  if (isNaN(photoId)) {
    res.status(400).json({ error: "Invalid photoId" });
    return;
  }

  const parsed = TagPersonInPhotoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  await db
    .insert(photoPeopleTable)
    .values({ photoId, personId: parsed.data.personId })
    .onConflictDoNothing();

  const [person] = await db
    .select()
    .from(peopleTable)
    .where(eq(peopleTable.id, parsed.data.personId));

  if (!person) {
    res.status(404).json({ error: "Person not found" });
    return;
  }

  const [pc] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(photoPeopleTable)
    .where(eq(photoPeopleTable.personId, person.id));

  res.status(201).json({
    id: person.id,
    name: person.name,
    relationship: person.relationship,
    birthYear: person.birthYear,
    deathYear: person.deathYear,
    notes: person.notes,
    photoCount: pc?.count ?? 0,
    createdAt: person.createdAt.toISOString(),
  });
});

export default router;
