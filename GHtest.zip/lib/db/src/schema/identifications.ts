import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { photosTable } from "./photos";

export const identificationsTable = pgTable("identifications", {
  id: serial("id").primaryKey(),
  photoId: integer("photo_id").notNull().references(() => photosTable.id, { onDelete: "cascade" }),
  contributorName: text("contributor_name").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull().$type<"person_name" | "location" | "story" | "date" | "general">(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertIdentificationSchema = createInsertSchema(identificationsTable).omit({ id: true, createdAt: true });
export type InsertIdentification = z.infer<typeof insertIdentificationSchema>;
export type Identification = typeof identificationsTable.$inferSelect;
