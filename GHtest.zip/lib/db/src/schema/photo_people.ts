import { pgTable, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { photosTable } from "./photos";
import { peopleTable } from "./people";

export const photoPeopleTable = pgTable("photo_people", {
  id: serial("id").primaryKey(),
  photoId: integer("photo_id").notNull().references(() => photosTable.id, { onDelete: "cascade" }),
  personId: integer("person_id").notNull().references(() => peopleTable.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type PhotoPerson = typeof photoPeopleTable.$inferSelect;
